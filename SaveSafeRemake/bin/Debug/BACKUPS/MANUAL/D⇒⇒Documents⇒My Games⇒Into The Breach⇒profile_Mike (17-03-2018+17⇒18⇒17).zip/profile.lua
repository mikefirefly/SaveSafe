Profile = {
["version"] = 1, ["opening"] = true, ["hide_tutorials"] = false, 
["last_squad"] = 0, ["last_pilot"] = 1, 
["timer"] = 8096417.000000, 
["unlocked_island"] = 1, 

["tutorials"] = {"Tutorial_Combat", "Tutorial_PowerGrid", "Tutorial_Drowning", "Tutorial_DamagedMech", "Tutorial_Rewards", "Tutorial_Spawning", "Tutorial_Webbed", "Tutorial_PushDamage", "Tutorial_PushDead", "Tutorial_Forest", "Tutorial_BuildingDamage", "Tutorial_Opening", "Tutorial_Shield", "Tutorial_GridDefense", "Tutorial_Jelly", "Tutorial_PushDeath", "Tutorial_Pod", "Tutorial_PodDestroyed", "Tutorial_Money", "Tutorial_Water", "Tutorial_WaterUndo", "Tutorial_InfoButton", "Tutorial_Cores", "Tutorial_Cores2", "Tutorial_Cores3", "Tutorial_Terraform", "Tutorial_Environment", "Tutorial_Weapon", "Tutorial_DeadPilot", },

["squads"] = {true, false, false, false, false, false, false, false, false, false, false, },

["pilots"] = {"Pilot_Original", },
["pilot"] = {["id"] = "Pilot_Pinnacle", ["name"] = "Cinnabar", ["skill1"] = 0, ["skill2"] = 3, ["exp"] = 18, ["level"] = 1, ["travel"] = 1, ["final"] = 0, ["starting"] = true, ["last_end"] = 2, },


["achievements"] = {["Archive_A_3"] = 1, ["Global_Pilot_Max"] = 1, ["Archive_A_1"] = 1, },

["trackers"] = {["Global_Island_Mechs"] = 6, ["Global_Challenge_Mods"] = 18, ["Global_Meta_Reputation"] = 8, ["Global_Pilot_Max"] = 1, ["Global_Island_Perfect"] = 4, ["Global_Challenge_Perfect"] = 6, ["Archive_A_3"] = 1, ["Global_Island_Rep"] = 3, ["Global_Island_Power"] = 1, ["Global_Island_Building"] = 7, ["Global_Meta_Rescue"] = 9968, ["Global_Pilot_Three"] = 1, ["Global_Challenge_Pods"] = 1, ["Global_Challenge_Power"] = 10, ["Global_Pilot_Unlocked"] = 1, ["Global_Challenge_New"] = 2, ["Global_Meta_Block"] = 11, },


["stat_tracker"] = {["games"] = 3, ["travelers"] = 2, ["kills"] = 83, ["islands"] = 1, ["pods"] = 1, ["total"] = 9968, ["victories"] = {0, 0, 0, },

["score0"] = {["score"] = 8379, ["time"] = 5899864.000000, ["kills"] = 56, ["damage"] = 0, ["failures"] = 6, ["difficulty"] = 1, ["victory"] = false, ["islands"] = 1, ["squad"] = 0, 
["mechs"] = {"PunchMech", "TankMech", "ArtiMech", },
["colors"] = {0, 0, 0, },
["weapons"] = {"Prime_Punchmech_A", "", "Brute_Tankmech", "", "Ranged_Artillerymech_A", "", },
["pilot0"] = {["id"] = "Pilot_Original", ["name"] = "Ralph Karlsson", ["skill1"] = 3, ["skill2"] = 1, ["exp"] = 50, ["level"] = 2, ["travel"] = 2, ["final"] = 0, ["starting"] = true, ["last_end"] = 2, },
["pilot1"] = {["id"] = "Pilot_Pinnacle", ["name"] = "Cinnabar", ["skill1"] = 0, ["skill2"] = 3, ["exp"] = 18, ["level"] = 1, ["travel"] = 1, ["final"] = 0, ["starting"] = true, ["last_end"] = 2, },
["pilot2"] = {["id"] = "Pilot_Archive", ["name"] = "Sergei Nguyen", ["skill1"] = 2, ["skill2"] = 0, ["exp"] = 29, ["level"] = 1, ["travel"] = 0, ["final"] = 0, ["starting"] = true, },
},

["score1"] = {["score"] = 832, ["time"] = 1150695.000000, ["kills"] = 16, ["damage"] = 0, ["failures"] = 1, ["difficulty"] = 1, ["victory"] = false, ["squad"] = 0, 
["mechs"] = {"PunchMech", "TankMech", "ArtiMech", },
["colors"] = {0, 0, 0, },
["weapons"] = {"Prime_Punchmech", "", "Brute_Tankmech", "", "Ranged_Artillerymech", "", },
["pilot0"] = {["id"] = "Pilot_Original", ["name"] = "Ralph Karlsson", ["skill1"] = 3, ["skill2"] = 1, ["exp"] = 0, ["level"] = 1, ["travel"] = 1, ["final"] = 0, ["starting"] = true, ["last_end"] = 2, },
["pilot1"] = {["id"] = "Pilot_Rust", ["name"] = "Sam Kim", ["skill1"] = 2, ["skill2"] = 3, ["exp"] = 8, ["level"] = 0, ["travel"] = 0, ["final"] = 0, ["starting"] = true, },
["pilot2"] = {["id"] = "Pilot_Archive", ["name"] = "Isabel Waller", ["skill1"] = 3, ["skill2"] = 1, ["exp"] = 3, ["level"] = 0, ["travel"] = 0, ["final"] = 0, ["starting"] = true, },
},

["score2"] = {["score"] = 757, ["time"] = 853775.000000, ["kills"] = 11, ["damage"] = 0, ["failures"] = 0, ["difficulty"] = 1, ["victory"] = false, ["squad"] = 0, 
["mechs"] = {"PunchMech", "TankMech", "ArtiMech", },
["colors"] = {0, 0, 0, },
["weapons"] = {"Prime_Punchmech", "", "Brute_Tankmech", "", "Ranged_Artillerymech", "", },
["pilot0"] = {["id"] = "Pilot_Original", ["name"] = "Ralph Karlsson", ["skill1"] = 3, ["skill2"] = 1, ["exp"] = 0, ["level"] = 2, ["travel"] = 2, ["final"] = 0, ["starting"] = true, ["last_end"] = 2, },
["pilot1"] = {["id"] = "Pilot_Archive", ["name"] = "Myra Singh", ["skill1"] = 2, ["skill2"] = 3, ["exp"] = 11, ["level"] = 0, ["travel"] = 0, ["final"] = 0, ["starting"] = true, },
["pilot2"] = {["id"] = "Pilot_Rust", ["name"] = "Isabel Kirk", ["skill1"] = 0, ["skill2"] = 1, ["exp"] = 4, ["level"] = 0, ["travel"] = 0, ["final"] = 0, ["starting"] = true, },
},


["squad0"] = {["victories"] = {0, 0, 0, },
["games"] = 3, ["score"] = 8379, ["kills"] = 85, },

["squad1"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["squad2"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["squad3"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["squad4"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["squad5"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["squad6"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["squad7"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["squad8"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["squad9"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["squad10"] = {["victories"] = {0, 0, 0, },
["games"] = 0, ["score"] = 0, ["kills"] = 0, },

["pilots"] = {

["Pilot_Original"] = {["battles"] = 15, ["kills"] = 25, ["travels"] = 2, },

["Pilot_Rust"] = {["battles"] = 4, ["kills"] = 2, },

["Pilot_Archive"] = {["battles"] = 15, ["kills"] = 14, },

["Pilot_Pinnacle"] = {["battles"] = 11, ["kills"] = 8, },
},

["enemies"] = {

["Firefly1"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 30, },

["Beetle1"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 3, ["damage"] = 3, },

["PunchMech"] = {["battles"] = 0, ["kills"] = 0, ["damage"] = 1, },

["Scarab1"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 5, ["damage"] = 1, },

["Jelly_Health1"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 5, },

["Firefly2"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 2, ["damage"] = 2, },

["Beetle2"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 1, ["damage"] = 1, },

["Scorpion1"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 18, ["damage"] = 4, },

["Jelly_Explode1"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 2, },

["Scorpion2"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 2, ["damage"] = 2, },

["Hornet1"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 14, ["damage"] = 3, },

["FireflyBoss"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 1, },

["Leaper1"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 1, },

["BlobBoss"] = {["battles"] = 0, ["kills"] = 0, ["deaths"] = 1, },
},
},
}
