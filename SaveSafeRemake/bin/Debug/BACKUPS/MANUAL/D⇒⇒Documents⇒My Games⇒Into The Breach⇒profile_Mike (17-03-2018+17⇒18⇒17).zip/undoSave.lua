GameData = {["save_version"] = 1, ["network"] = 1, ["networkMax"] = 7, ["overflow"] = 0, ["seed"] = 29072, ["difficulty"] = 1, ["ach_info"] = {["squad"] = "Archive_A", ["trackers"] = {["Detritus_B_2"] = 0, ["Global_Challenge_Power"] = 9, ["Archive_A_1"] = 0, ["Archive_B_2"] = 0, ["Rust_A_2"] = 0, ["Rust_A_3"] = 0, ["Pinnacle_A_3"] = 0, ["Archive_B_1"] = 0, ["Pinnacle_B_3"] = 0, ["Detritus_B_1"] = 0, ["Pinnacle_B_1"] = 0, ["Global_Island_Mechs"] = 6, ["Global_Island_Building"] = 6, },
},


["current"] = {["score"] = 8379, ["time"] = 5711142.500000, ["kills"] = 56, ["damage"] = 0, ["failures"] = 6, ["difficulty"] = 1, ["victory"] = false, ["islands"] = 1, ["squad"] = 0, 
["mechs"] = {"PunchMech", "TankMech", "ArtiMech", },
["colors"] = {0, 0, 0, },
["weapons"] = {"Prime_Punchmech_A", "", "Brute_Tankmech", "", "Ranged_Artillerymech_A", "", },
["pilot0"] = {["id"] = "Pilot_Original", ["name"] = "Ralph Karlsson", ["skill1"] = 3, ["skill2"] = 1, ["exp"] = 50, ["level"] = 2, ["travel"] = 2, ["final"] = 0, ["starting"] = true, ["last_end"] = 2, },
["pilot1"] = {["id"] = "Pilot_Pinnacle", ["name"] = "Cinnabar", ["skill1"] = 0, ["skill2"] = 3, ["exp"] = 18, ["level"] = 1, ["travel"] = 0, ["final"] = 0, ["starting"] = true, },
["pilot2"] = {["id"] = "Pilot_Archive", ["name"] = "Sergei Nguyen", ["skill1"] = 2, ["skill2"] = 0, ["exp"] = 29, ["level"] = 1, ["travel"] = 0, ["final"] = 0, ["starting"] = true, },
},
["current_squad"] = 0, ["undosave"] = true, }
 

RegionData = {
["sector"] = 1, ["island"] = 1, ["secret"] = false, 
["island0"] = {["corporation"] = "Corp_Grass", ["id"] = 0, ["secured"] = true, },
["island1"] = {["corporation"] = "Corp_Desert", ["id"] = 1, ["secured"] = false, },
["island2"] = {["corporation"] = "Corp_Snow", ["id"] = 2, ["secured"] = false, },
["island3"] = {["corporation"] = "Corp_Factory", ["id"] = 3, ["secured"] = false, },

["turn"] = 4, ["iTower"] = 6, ["quest_tracker"] = 1, ["quest_id"] = 0, ["podRewards"] = {},


["region0"] = {["mission"] = "", ["state"] = 2, ["name"] = "Restricted Area", ["objectives"] = {["0"] = {["text"] = "Defend the Terraformer", ["value"] = 1, ["potential"] = 1, ["category"] = 0, },
["1"] = {["text"] = "Terraform the grassland back to desert (Failed)", ["value"] = 0, ["potential"] = 1, ["category"] = 0, },
},
},

["region1"] = {["mission"] = "", ["state"] = 3, ["name"] = "Proving Grounds", ["objectives"] = {},
},

["region2"] = {["mission"] = "", ["state"] = 3, ["name"] = "Phoenix Park", ["objectives"] = {["0"] = {["text"] = "End battle with less than 4 Mech Damage", ["value"] = 1, ["potential"] = 1, ["category"] = 0, },
},
},

["region3"] = {["mission"] = "", ["state"] = 2, ["name"] = "Maglev Bunkers", ["objectives"] = {["0"] = {["text"] = "Defend Prototype Renfield Bombs (One Lost)", ["value"] = 1, ["potential"] = 2, ["category"] = 0, },
},
},

["region4"] = {["mission"] = "", ["state"] = 2, ["name"] = "Erosion Flats", ["objectives"] = {["0"] = {["text"] = "Destroy 2 mountains (Failed)", ["value"] = 0, ["potential"] = 1, ["category"] = 0, },
["1"] = {["text"] = "Kill at least 7 Enemies (Failed)", ["value"] = 0, ["potential"] = 1, ["category"] = 0, },
["2"] = {["text"] = "Protect the Defense Lab", ["value"] = 1, ["potential"] = 1, ["category"] = 2, },
["3"] = {["text"] = "Protect the Time Pod", ["value"] = 1, ["potential"] = 1, ["category"] = 3, },
},
},

["region5"] = {["mission"] = "", ["state"] = 2, ["name"] = "Storm Summit", ["objectives"] = {["0"] = {["text"] = "Kill at least 7 Enemies", ["value"] = 1, ["potential"] = 1, ["category"] = 0, },
["1"] = {["text"] = "Protect the Emergency Batteries", ["value"] = 1, ["potential"] = 1, ["category"] = 1, },
},
},

["region6"] = {["mission"] = "Mission8", ["player"] = {["battle_type"] = 1, ["iCurrentTurn"] = 2, ["iTeamTurn"] = 1, ["iState"] = 0, ["sMission"] = "Mission8", ["podReward"] = CreateEffect({}), ["secret"] = false, ["spawn_needed"] = false, ["env_time"] = 1000, ["actions"] = 0, ["iUndoTurn"] = 1, ["aiState"] = 3, ["aiDelay"] = 0.000000, ["victory"] = 2, ["undo_pawns"] = {},


["map_data"] = {["version"] = 7, ["dimensions"] = Point( 8, 8 ), ["name"] = "any15", 
["map"] = {{["loc"] = Point( 0, 5 ), ["terrain"] = 7, },
{["loc"] = Point( 0, 6 ), ["terrain"] = 1, ["populated"] = 1, ["people1"] = 123, ["people2"] = 0, ["health_max"] = 1, },
{["loc"] = Point( 1, 1 ), ["terrain"] = 2, ["health_max"] = 1, ["health_min"] = 0, ["rubble_type"] = 0, },
{["loc"] = Point( 1, 2 ), ["terrain"] = 1, ["populated"] = 1, ["unique"] = "str_tower1", ["people1"] = 93, ["people2"] = 0, ["health_max"] = 1, },
{["loc"] = Point( 1, 4 ), ["terrain"] = 0, },
{["loc"] = Point( 1, 6 ), ["terrain"] = 1, ["populated"] = 1, ["people1"] = 210, ["people2"] = 0, ["health_max"] = 2, },
{["loc"] = Point( 2, 1 ), ["terrain"] = 0, },
{["loc"] = Point( 2, 3 ), ["terrain"] = 0, ["undo_state"] = {["active"] = true, },
},
{["loc"] = Point( 2, 4 ), ["terrain"] = 0, ["undo_state"] = {["active"] = true, },
},
{["loc"] = Point( 2, 5 ), ["terrain"] = 0, ["undo_state"] = {["active"] = true, },
},
{["loc"] = Point( 2, 7 ), ["terrain"] = 7, ["undo_state"] = {["terrain"] = 7, ["active"] = true, },
},
{["loc"] = Point( 3, 0 ), ["terrain"] = 7, },
{["loc"] = Point( 3, 3 ), ["terrain"] = 1, ["populated"] = 1, ["people1"] = 211, ["people2"] = 0, ["health_max"] = 2, },
{["loc"] = Point( 3, 4 ), ["terrain"] = 1, ["populated"] = 1, ["people1"] = 234, ["people2"] = 0, ["health_max"] = 2, },
{["loc"] = Point( 4, 0 ), ["terrain"] = 4, },
{["loc"] = Point( 4, 3 ), ["terrain"] = 4, },
{["loc"] = Point( 4, 4 ), ["terrain"] = 4, },
{["loc"] = Point( 4, 7 ), ["terrain"] = 7, },
{["loc"] = Point( 5, 0 ), ["terrain"] = 4, },
{["loc"] = Point( 5, 2 ), ["terrain"] = 7, },
{["loc"] = Point( 5, 3 ), ["terrain"] = 4, },
{["loc"] = Point( 5, 4 ), ["terrain"] = 4, },
{["loc"] = Point( 5, 6 ), ["terrain"] = 0, },
{["loc"] = Point( 5, 7 ), ["terrain"] = 4, },
{["loc"] = Point( 6, 0 ), ["terrain"] = 4, },
{["loc"] = Point( 6, 4 ), ["terrain"] = 7, },
{["loc"] = Point( 6, 7 ), ["terrain"] = 4, ["health_max"] = 2, ["health_min"] = 1, },
{["loc"] = Point( 7, 0 ), ["terrain"] = 4, },
{["loc"] = Point( 7, 1 ), ["terrain"] = 4, },
{["loc"] = Point( 7, 2 ), ["terrain"] = 7, },
{["loc"] = Point( 7, 4 ), ["terrain"] = 7, },
{["loc"] = Point( 7, 6 ), ["terrain"] = 4, },
{["loc"] = Point( 7, 7 ), ["terrain"] = 4, },
},
["pod"] = Point(5,1), ["spawns"] = {"Firefly1", },
["spawn_ids"] = {194, },
["spawn_points"] = {Point(6,5), },
["zones"] = {},
["tags"] = {"generic", "any_sector", },


["pawn1"] = {["type"] = "PunchMech", ["name"] = "", ["id"] = 0, ["mech"] = true, ["offset"] = 0, 
["reactor"] = {["iNormalPower"] = 0, ["iUsedPower"] = 2, ["iBonusPower"] = 0, ["iUsedBonus"] = 1, ["iUndoPower"] = 0, ["iUsedUndo"] = 0, },
["movePower"] = {0, },
["healthPower"] = {0, },
["primary"] = "Prime_Punchmech", ["primary_power"] = {1, },
["primary_power_class"] = false, ["primary_mod1"] = {1, 2, },
["primary_mod2"] = {0, 0, 0, },
["primary_uses"] = 1, ["primary_damaged"] = false, ["primary_starting"] = true, ["pilot"] = {["id"] = "Pilot_Original", ["name"] = "Ralph Karlsson", ["skill1"] = 3, ["skill2"] = 1, ["exp"] = 50, ["level"] = 2, ["travel"] = 2, ["final"] = 0, ["starting"] = true, ["last_end"] = 2, },
["iTeamId"] = 1, ["iFaction"] = 0, ["health"] = 3, ["max_health"] = 3, ["undo_state"] = {["health"] = 3, ["max_health"] = 3, },
["undo_ready"] = false, ["undo_point"] = Point(2,4), ["iMissionDamage"] = 0, ["location"] = Point(2,4), ["last_location"] = Point(2,5), ["bActive"] = true, ["iCurrentWeapon"] = 0, ["iTurnCount"] = 2, ["undoPosition"] = Point(2,4), ["undoReady"] = false, ["iKillCount"] = 1, ["iOwner"] = 0, ["piTarget"] = Point(-1,-1), ["piOrigin"] = Point(2,4), ["piQueuedShot"] = Point(-1,-1), ["iQueuedSkill"] = -1, ["priorityTarget"] = Point(-1,-1), ["targetHistory"] = Point(-1,-1), },


["pawn2"] = {["type"] = "TankMech", ["name"] = "", ["id"] = 1, ["mech"] = true, ["offset"] = 0, 
["reactor"] = {["iNormalPower"] = 0, ["iUsedPower"] = 1, ["iBonusPower"] = 0, ["iUsedBonus"] = 0, ["iUndoPower"] = 0, ["iUsedUndo"] = 0, },
["movePower"] = {0, },
["healthPower"] = {0, },
["primary"] = "Brute_Tankmech", ["primary_power"] = {1, },
["primary_power_class"] = false, ["primary_mod1"] = {0, 0, },
["primary_mod2"] = {0, 0, 0, },
["primary_uses"] = 1, ["primary_damaged"] = false, ["primary_starting"] = true, ["pilot"] = {["id"] = "Pilot_Pinnacle", ["name"] = "Cinnabar", ["skill1"] = 0, ["skill2"] = 3, ["exp"] = 18, ["level"] = 1, ["travel"] = 0, ["final"] = 0, ["starting"] = true, },
["iTeamId"] = 1, ["iFaction"] = 0, ["health"] = 5, ["max_health"] = 5, ["undo_state"] = {["health"] = 5, ["max_health"] = 5, },
["undo_ready"] = false, ["undo_point"] = Point(2,3), ["iMissionDamage"] = 0, ["location"] = Point(2,3), ["last_location"] = Point(2,4), ["bActive"] = true, ["iCurrentWeapon"] = 0, ["iTurnCount"] = 2, ["undoPosition"] = Point(2,3), ["undoReady"] = false, ["iKillCount"] = 1, ["iOwner"] = 1, ["piTarget"] = Point(2,4), ["piOrigin"] = Point(2,3), ["piQueuedShot"] = Point(-1,-1), ["iQueuedSkill"] = -1, ["priorityTarget"] = Point(-1,-1), ["targetHistory"] = Point(-1,-1), },


["pawn3"] = {["type"] = "ArtiMech", ["name"] = "", ["id"] = 2, ["mech"] = true, ["offset"] = 0, 
["reactor"] = {["iNormalPower"] = 0, ["iUsedPower"] = 2, ["iBonusPower"] = 0, ["iUsedBonus"] = 0, ["iUndoPower"] = 0, ["iUsedUndo"] = 0, },
["movePower"] = {0, },
["healthPower"] = {0, },
["primary"] = "Ranged_Artillerymech", ["primary_power"] = {1, },
["primary_power_class"] = false, ["primary_mod1"] = {1, },
["primary_mod2"] = {0, 0, 0, },
["primary_uses"] = 1, ["primary_damaged"] = false, ["primary_starting"] = true, ["secondary"] = "Ranged_Fireball", ["secondary_power"] = {0, },
["secondary_power_class"] = false, ["secondary_mod1"] = {0, 0, },
["secondary_mod2"] = {0, },
["secondary_uses"] = 1, ["secondary_damaged"] = false, ["secondary_starting"] = true, ["pilot"] = {["id"] = "Pilot_Archive", ["name"] = "Sergei Nguyen", ["skill1"] = 2, ["skill2"] = 0, ["exp"] = 29, ["level"] = 1, ["travel"] = 0, ["final"] = 0, ["starting"] = true, },
["iTeamId"] = 1, ["iFaction"] = 0, ["health"] = 2, ["max_health"] = 2, ["undo_state"] = {["health"] = 2, ["max_health"] = 2, },
["undo_ready"] = false, ["undo_point"] = Point(2,7), ["iMissionDamage"] = 0, ["location"] = Point(2,7), ["last_location"] = Point(2,6), ["bActive"] = true, ["iCurrentWeapon"] = 0, ["iTurnCount"] = 2, ["undoPosition"] = Point(2,7), ["undoReady"] = false, ["iKillCount"] = 1, ["iOwner"] = 2, ["piTarget"] = Point(6,7), ["piOrigin"] = Point(2,7), ["piQueuedShot"] = Point(-1,-1), ["iQueuedSkill"] = -1, ["priorityTarget"] = Point(-1,-1), ["targetHistory"] = Point(6,7), },


["pawn4"] = {["type"] = "Firefly2", ["name"] = "", ["id"] = 161, ["mech"] = false, ["offset"] = 1, ["primary"] = "FireflyAtk2", ["iTeamId"] = 6, ["iFaction"] = 0, ["health"] = 4, ["max_health"] = 5, ["undo_state"] = {["health"] = 5, ["max_health"] = 5, },
["undo_ready"] = false, ["undo_point"] = Point(-1,-1), ["iMissionDamage"] = 0, ["location"] = Point(5,6), ["last_location"] = Point(5,5), ["iCurrentWeapon"] = 1, ["iTurnCount"] = 2, ["undoPosition"] = Point(-1,-1), ["undoReady"] = false, ["iKillCount"] = 0, ["iOwner"] = 161, ["piTarget"] = Point(4,6), ["piOrigin"] = Point(5,6), ["piQueuedShot"] = Point(4,6), ["iQueuedSkill"] = 1, ["priorityTarget"] = Point(-1,-1), ["targetHistory"] = Point(4,6), },


["pawn5"] = {["type"] = "Beetle1", ["name"] = "", ["id"] = 162, ["mech"] = false, ["offset"] = 0, ["primary"] = "BeetleAtk1", ["iTeamId"] = 6, ["iFaction"] = 0, ["health"] = 4, ["max_health"] = 4, ["undo_state"] = {["health"] = 5, ["max_health"] = 5, },
["undo_ready"] = false, ["undo_point"] = Point(-1,-1), ["iMissionDamage"] = 0, ["location"] = Point(2,1), ["last_location"] = Point(2,1), ["iCurrentWeapon"] = 1, ["iTurnCount"] = 2, ["undoPosition"] = Point(-1,-1), ["undoReady"] = false, ["iKillCount"] = 0, ["iOwner"] = 162, ["piTarget"] = Point(2,2), ["piOrigin"] = Point(2,1), ["piQueuedShot"] = Point(2,2), ["iQueuedSkill"] = 1, ["priorityTarget"] = Point(-1,-1), ["targetHistory"] = Point(2,2), },


["pawn6"] = {["type"] = "BlobBossMed", ["name"] = "", ["id"] = 196, ["mech"] = false, ["offset"] = 0, ["owner"] = 161, ["death_seed"] = 3610, ["primary"] = "BlobBossAtkMed", ["iTeamId"] = 6, ["iFaction"] = 0, ["health"] = 2, ["max_health"] = 2, ["undo_state"] = {["health"] = 5, ["max_health"] = 5, },
["undo_ready"] = false, ["undo_point"] = Point(-1,-1), ["iMissionDamage"] = 0, ["location"] = Point(1,4), ["last_location"] = Point(1,5), ["iCurrentWeapon"] = 1, ["iTurnCount"] = 1, ["undoPosition"] = Point(-1,-1), ["undoReady"] = false, ["iKillCount"] = 0, ["iOwner"] = 196, ["piTarget"] = Point(2,4), ["piOrigin"] = Point(1,4), ["piQueuedShot"] = Point(2,4), ["iQueuedSkill"] = 1, ["priorityTarget"] = Point(-1,-1), ["targetHistory"] = Point(2,4), },


["pawn7"] = {["type"] = "BlobBossMed", ["name"] = "", ["id"] = 197, ["mech"] = false, ["offset"] = 0, ["owner"] = 161, ["death_seed"] = 3258, ["primary"] = "BlobBossAtkMed", ["iTeamId"] = 6, ["iFaction"] = 0, ["health"] = 2, ["max_health"] = 2, ["undo_state"] = {["health"] = 5, ["max_health"] = 5, },
["undo_ready"] = false, ["undo_point"] = Point(-1,-1), ["iMissionDamage"] = 0, ["location"] = Point(2,5), ["last_location"] = Point(2,5), ["iCurrentWeapon"] = 1, ["iTurnCount"] = 1, ["undoPosition"] = Point(-1,-1), ["undoReady"] = false, ["iKillCount"] = 0, ["iOwner"] = 197, ["piTarget"] = Point(2,4), ["piOrigin"] = Point(2,5), ["piQueuedShot"] = Point(2,4), ["iQueuedSkill"] = 1, ["priorityTarget"] = Point(-1,-1), ["targetHistory"] = Point(2,4), },


["pawn8"] = {["type"] = "Scarab1", ["name"] = "", ["id"] = 195, ["mech"] = false, ["offset"] = 0, ["primary"] = "ScarabAtk1", ["iTeamId"] = 6, ["iFaction"] = 0, ["health"] = 2, ["max_health"] = 2, ["undo_state"] = {["health"] = 5, ["max_health"] = 5, },
["undo_ready"] = false, ["undo_point"] = Point(-1,-1), ["iMissionDamage"] = 0, ["location"] = Point(6,4), ["last_location"] = Point(6,5), ["iCurrentWeapon"] = 1, ["iTurnCount"] = 0, ["undoPosition"] = Point(-1,-1), ["undoReady"] = false, ["iKillCount"] = 0, ["iOwner"] = 195, ["piTarget"] = Point(3,4), ["piOrigin"] = Point(6,4), ["piQueuedShot"] = Point(3,4), ["iQueuedSkill"] = 1, ["priorityTarget"] = Point(-1,-1), ["targetHistory"] = Point(3,4), },
["pawn_count"] = 8, ["blocked_points"] = {},
["blocked_type"] = {},
},


},
["state"] = 1, ["name"] = "Corporate HQ", },

["region7"] = {["mission"] = "", ["state"] = 3, ["name"] = "Detonation Bay", ["objectives"] = {},
},
["iBattleRegion"] = 6, }
 

GAME = { 
["Enemies"] = { 
[1] = { 
[6] = "Blobber", 
[2] = "Scorpion", 
[3] = "Firefly", 
[1] = "Hornet", 
[4] = "Jelly_Health", 
[5] = "Crab", 
["island"] = 1 
}, 
[2] = { 
[6] = "Blobber", 
[2] = "Scorpion", 
[3] = "Firefly", 
[1] = "Scarab", 
[4] = "Jelly_Explode", 
[5] = "Beetle", 
["island"] = 2 
}, 
[4] = { 
[6] = "Burrower", 
[2] = "Firefly", 
[3] = "Leaper", 
[1] = "Hornet", 
[4] = "Jelly_Regen", 
[5] = "Crab", 
["island"] = 4 
}, 
[3] = { 
[6] = "Digger", 
[2] = "Scarab", 
[3] = "Leaper", 
[1] = "Hornet", 
[4] = "Jelly_Armor", 
[5] = "Beetle", 
["island"] = 3 
} 
}, 
["Island"] = 2, 
["Missions"] = { 
[6] = { 
["BonusObjs"] = { 
[1] = 6, 
[2] = 1 
}, 
["Mountains"] = 1, 
["KilledVek"] = 6, 
["Spawner"] = { 
["curr_weakRatio"] = { 
[1] = 1, 
[2] = 2 
}, 
["upgrade_streak"] = 0, 
["curr_upgradeRatio"] = { 
[1] = 0, 
[2] = 2 
}, 
["num_spawns"] = 8, 
["pawn_counts"] = { 
["Scarab"] = 2, 
["Beetle"] = 1, 
["Scorpion"] = 2, 
["Firefly"] = 3, 
["Jelly_Explode"] = 1 
} 
}, 
["LiveEnvironment"] = { 
}, 
["AssetId"] = "Str_Research", 
["AssetLoc"] = Point( 1, 1 ), 
["ID"] = "Mission_Force", 
["VoiceEvents"] = { 
}, 
["DiffMod"] = 2, 
["PowerStart"] = 7 
}, 
[2] = { 
["Spawner"] = { 
["curr_weakRatio"] = { 
[1] = 1, 
[2] = 2 
}, 
["pawn_counts"] = { 
["Firefly"] = 1, 
["Scarab"] = 1, 
["Jelly_Explode"] = 1 
}, 
["curr_upgradeRatio"] = { 
[1] = 1, 
[2] = 2 
}, 
["num_spawns"] = 3, 
["upgrade_streak"] = 0 
}, 
["BonusObjs"] = { 
[1] = 4 
}, 
["ID"] = "Mission_Holes", 
["VoiceEvents"] = { 
}, 
["DiffMod"] = 1, 
["LiveEnvironment"] = { 
} 
}, 
[8] = { 
["BossID"] = 160, 
["BonusObjs"] = { 
[1] = 1 
}, 
["Spawner"] = { 
["curr_weakRatio"] = { 
[1] = 1, 
[2] = 1 
}, 
["pawn_counts"] = { 
["Firefly"] = 2, 
["Scarab"] = 1, 
["Beetle"] = 1, 
["Jelly_Explode"] = 5 
}, 
["curr_upgradeRatio"] = { 
[1] = 0, 
[2] = 1 
}, 
["num_spawns"] = 4, 
["upgrade_streak"] = 0 
}, 
["LiveEnvironment"] = { 
}, 
["BlobList"] = { 
[197] = true, 
[196] = true, 
[160] = true 
}, 
["AssetLoc"] = Point( 1, 2 ), 
["ID"] = "Mission_BlobBoss", 
["VoiceEvents"] = { 
}, 
["AssetId"] = "Str_Tower", 
["PowerStart"] = 2 
}, 
[3] = { 
["Filler"] = 15, 
["BonusObjs"] = { 
[1] = 5, 
[2] = 1 
}, 
["Spawner"] = { 
["curr_weakRatio"] = { 
[1] = 2, 
[2] = 2 
}, 
["upgrade_streak"] = 0, 
["curr_upgradeRatio"] = { 
[1] = 0, 
[2] = 2 
}, 
["num_spawns"] = 3, 
["pawn_counts"] = { 
["Beetle"] = 1, 
["Scarab"] = 1, 
["Firefly"] = 1, 
["Jelly_Explode"] = 1 
} 
}, 
["LiveEnvironment"] = { 
}, 
["AssetLoc"] = Point( 1, 1 ), 
["ID"] = "Mission_Filler", 
["VoiceEvents"] = { 
}, 
["DiffMod"] = 2, 
["AssetId"] = "Str_Nimbus" 
}, 
[1] = { 
["Spawner"] = { 
["curr_weakRatio"] = { 
[1] = 1, 
[2] = 1 
}, 
["upgrade_streak"] = 0, 
["curr_upgradeRatio"] = { 
[1] = 1, 
[2] = 1 
}, 
["num_spawns"] = 9, 
["pawn_counts"] = { 
["Firefly"] = 3, 
["Scorpion"] = 3, 
["Beetle"] = 2, 
["Jelly_Explode"] = 1 
} 
}, 
["LiveEnvironment"] = { 
}, 
["TerraformerId"] = 8, 
["ID"] = "Mission_Terraform", 
["VoiceEvents"] = { 
}, 
["BonusObjs"] = { 
}, 
["PowerStart"] = 7 
}, 
[4] = { 
["BonusObjs"] = { 
[1] = 6, 
[2] = 1 
}, 
["Spawner"] = { 
["curr_weakRatio"] = { 
[1] = 0, 
[2] = 1 
}, 
["upgrade_streak"] = 1, 
["curr_upgradeRatio"] = { 
[1] = 0, 
[2] = 1 
}, 
["num_spawns"] = 9, 
["pawn_counts"] = { 
["Scarab"] = 1, 
["Beetle"] = 1, 
["Scorpion"] = 3, 
["Firefly"] = 3, 
["Jelly_Explode"] = 1 
} 
}, 
["LiveEnvironment"] = { 
["Index"] = 3 
}, 
["KilledVek"] = 9, 
["AssetLoc"] = Point( 3, 2 ), 
["ID"] = "Mission_Cataclysm", 
["VoiceEvents"] = { 
}, 
["AssetId"] = "Str_Battery", 
["PowerStart"] = 6 
}, 
[5] = { 
["BonusObjs"] = { 
[1] = 6, 
[2] = 1 
}, 
["SpawnStart_Easy"] = { 
[1] = 2, 
[2] = 2, 
[4] = 3, 
[3] = 3 
}, 
["SpawnStart"] = { 
[1] = 3, 
[2] = 3, 
[4] = 4, 
[3] = 4 
}, 
["InfiniteSpawn"] = true, 
["SpawnsPerTurn_Easy"] = { 
[1] = 2, 
[2] = 1 
}, 
["Spawner"] = { 
["curr_weakRatio"] = { 
[1] = 2, 
[2] = 2 
}, 
["pawn_counts"] = { 
["Beetle"] = 1, 
["Scorpion"] = 1, 
["Jelly_Explode"] = 1 
}, 
["curr_upgradeRatio"] = { 
[1] = 1, 
[2] = 2 
}, 
["num_spawns"] = 3, 
["upgrade_streak"] = 0 
}, 
["LiveEnvironment"] = { 
["Locations"] = { 
}, 
["Planned"] = { 
} 
}, 
["BonusPool"] = { 
[1] = 3, 
[2] = 4, 
[4] = 6, 
[3] = 5 
}, 
["AssetLoc"] = Point( 5, 0 ), 
["ID"] = "Mission_Lightning", 
["VoiceEvents"] = { 
}, 
["AssetId"] = "Str_Power", 
["SpawnsPerTurn"] = { 
[1] = 2, 
[2] = 3 
} 
}, 
[7] = { 
["Spawner"] = { 
["curr_weakRatio"] = { 
[1] = 2, 
[2] = 2 
}, 
["upgrade_streak"] = 1, 
["curr_upgradeRatio"] = { 
[1] = 0, 
[2] = 2 
}, 
["num_spawns"] = 8, 
["pawn_counts"] = { 
["Beetle"] = 2, 
["Scarab"] = 2, 
["Firefly"] = 3, 
["Scorpion"] = 1 
} 
}, 
["LiveEnvironment"] = { 
}, 
["Bombs"] = { 
[1] = 84, 
[2] = 85 
}, 
["ID"] = "Mission_Bomb", 
["VoiceEvents"] = { 
}, 
["BonusObjs"] = { 
}, 
["PowerStart"] = 2 
} 
}, 
["WeaponDeck"] = { 
[31] = "Ranged_Ice", 
[2] = "Prime_Rockmech", 
[8] = "Prime_Spear", 
[32] = "Ranged_SmokeBlast", 
[33] = "Ranged_RainingVolley", 
[34] = "Ranged_Wide", 
[35] = "Ranged_Dual", 
[9] = "Prime_Leap", 
[36] = "Science_Pullmech", 
[37] = "Science_Gravwell", 
[38] = "Science_Swap", 
[39] = "Science_Repulse", 
[10] = "Prime_SpinFist", 
[40] = "Science_AcidShot", 
[41] = "Science_Confuse", 
[42] = "Science_SmokeDefense", 
[43] = "Science_Shield", 
[11] = "Prime_Sword", 
[44] = "Science_FireBeam", 
[45] = "Science_LocalShield", 
[46] = "Science_PushBeam", 
[3] = "Prime_RightHook", 
[12] = "Brute_Jetmech", 
[48] = "Support_Refrigerate", 
[49] = "DeploySkill_ShieldTank", 
[50] = "DeploySkill_Tank", 
[51] = "DeploySkill_AcidTank", 
[13] = "Brute_Mirrorshot", 
[52] = "DeploySkill_PullTank", 
[53] = "Support_Force", 
[54] = "Support_Missiles", 
[55] = "Support_Wind", 
[14] = "Brute_PhaseShot", 
[56] = "Support_Blizzard", 
[57] = "Passive_FlameImmune", 
[58] = "Passive_Electric", 
[59] = "Passive_Leech", 
[15] = "Brute_Grapple", 
[60] = "Passive_Defenses", 
[61] = "Passive_Burrows", 
[62] = "Passive_AutoShields", 
[1] = "Prime_Lasermech", 
[4] = "Prime_RocketPunch", 
[16] = "Brute_Shrapnel", 
[64] = "Passive_Medical", 
[65] = "Passive_FriendlyFire", 
[66] = "Passive_ForceAmp", 
[17] = "Brute_Sniper", 
[18] = "Brute_Shockblast", 
[19] = "Brute_Beetle", 
[5] = "Prime_Shift", 
[20] = "Brute_Unstable", 
[21] = "Brute_Heavyrocket", 
[22] = "Brute_Splitshot", 
[23] = "Brute_Bombrun", 
[6] = "Prime_Flamethrower", 
[24] = "Brute_Sonic", 
[25] = "Ranged_Rockthrow", 
[26] = "Ranged_Defensestrike", 
[27] = "Ranged_Rocket", 
[7] = "Prime_Areablast", 
[28] = "Ranged_Ignite", 
[29] = "Ranged_ScatterShot", 
[47] = "Support_Smoke", 
[30] = "Ranged_BackShot", 
[63] = "Passive_Psions", 
[67] = "Passive_CritDefense" 
}, 
["Bosses"] = { 
[1] = "Mission_FireflyBoss", 
[2] = "Mission_BlobBoss", 
[4] = "Mission_ScorpionBoss", 
[3] = "Mission_BeetleBoss" 
}, 
["PodDeck"] = { 
[6] = { 
["cores"] = 1, 
["pilot"] = "random" 
}, 
[7] = { 
["cores"] = 1, 
["pilot"] = "random" 
}, 
[8] = { 
["cores"] = 1, 
["pilot"] = "random" 
}, 
[3] = { 
["cores"] = 1, 
["weapon"] = "random" 
}, 
[1] = { 
["cores"] = 1 
}, 
[4] = { 
["cores"] = 1, 
["weapon"] = "random" 
}, 
[5] = { 
["cores"] = 1, 
["weapon"] = "random" 
}, 
[2] = { 
["cores"] = 1 
} 
}, 
["PilotDeck"] = { 
[7] = "Pilot_Genius", 
[1] = "Pilot_Soldier", 
[2] = "Pilot_Youth", 
[4] = "Pilot_Aquatic", 
[8] = "Pilot_Miner", 
[9] = "Pilot_Assassin", 
[5] = "Pilot_Medic", 
[10] = "Pilot_Repairman", 
[3] = "Pilot_Warrior", 
[6] = "Pilot_Hotshot" 
}, 
["SeenPilots"] = { 
[2] = "Pilot_Pinnacle", 
[3] = "Pilot_Archive", 
[1] = "Pilot_Original", 
[4] = "Pilot_Leader", 
[5] = "Pilot_Recycler" 
} 
}

 

SquadData = {
["money"] = 3, ["cores"] = 2, ["bIsFavor"] = false, ["repairs"] = 0, ["CorpReward"] = {CreateEffect({weapon = "Prime_Lightning",}), CreateEffect({pilot = "Pilot_Recycler",}), CreateEffect({power = 2,}), },
["RewardClaimed"] = false, 
["skip_pawns"] = true, 

["storage_size"] = 6, ["storage_3"] = {},
["storage_4"] = {},
["storage_5"] = {},
["CorpStore"] = {CreateEffect({weapon = "Support_SmokeDrop",money = -2,}), CreateEffect({weapon = "Support_Boosters",money = -2,}), CreateEffect({weapon = "Passive_MassRepair",money = -1,}), CreateEffect({weapon = "Passive_Boosters",money = -2,}), CreateEffect({money = -3,stock = -1,cores = 1,}), CreateEffect({money = -1,power = 1,stock = -1,}), },
}
 

